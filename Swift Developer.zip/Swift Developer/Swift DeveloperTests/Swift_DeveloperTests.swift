//
//  Swift_DeveloperTests.swift
//  Swift DeveloperTests
//
//  Created by Madi Kopessov on 08.09.2025.
//

import Testing
@testable import Swift_Developer

struct Swift_DeveloperTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
