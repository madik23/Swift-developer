//
//  UIApplication+Extension.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 09.09.2025.
//

import UIKit

extension UIApplication {
    func setRootViewController(_ vc: UIViewController, animated: Bool = true) {
        guard let windowScene = UIApplication.shared.connectedScenes
            .compactMap({ $0 as? UIWindowScene })
            .first(where: { $0.activationState == .foregroundActive }),
              let window = windowScene.windows.first(where: { $0.isKeyWindow }) else {
            return
        }
        
        if animated {
            UIView.transition(with: window,
                              duration: 0.4,
                              options: .transitionCrossDissolve,
                              animations: {
                                window.rootViewController = vc
                              },
                              completion: nil)
        } else {
            window.rootViewController = vc
            window.makeKeyAndVisible()
        }
    }
}
