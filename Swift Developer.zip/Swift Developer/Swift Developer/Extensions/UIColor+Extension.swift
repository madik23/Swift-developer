//
//  UIColor+Extension.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 08.09.2025.
//

import UIKit

// MARK: Hex colors

public extension UIColor {
    convenience init(hex: UInt32) {
        self.init(
            red: CGFloat((hex & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((hex & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(hex & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }

    convenience init(hex: String) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")

        guard let intHex = UInt32(hexSanitized, radix: 16) else {
            fatalError("Incorrect string hex")
        }

        self.init(hex: intHex)
    }
}
