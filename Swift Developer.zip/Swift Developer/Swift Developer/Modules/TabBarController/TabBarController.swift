//
//  TabBarController.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 08.09.2025.
//

import UIKit

class TabBarController: UITabBarController {
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTabs()
    }
    
    private func setupTabs() {
        let homeVC = UINavigationController(rootViewController: MainPageViewController())
        homeVC.topViewController?.view.backgroundColor = .white
        homeVC.tabBarItem = UITabBarItem(title: "Home", image: UIImage(systemName: "house"), tag: 0)

        let searchVC = UINavigationController(rootViewController: UIViewController())
        searchVC.topViewController?.view.backgroundColor = .white
        searchVC.tabBarItem = UITabBarItem(title: "Search", image: UIImage(systemName: "magnifyingglass"), tag: 1)

        let addVC = UINavigationController(rootViewController: UIViewController())
        addVC.topViewController?.view.backgroundColor = .white
        addVC.tabBarItem = UITabBarItem(title: "Add", image: UIImage(systemName: "plus.circle"), tag: 2)

        let notificationsVC = UINavigationController(rootViewController: UIViewController())
        notificationsVC.topViewController?.view.backgroundColor = .white
        notificationsVC.tabBarItem = UITabBarItem(title: "Alerts", image: UIImage(systemName: "bell"), tag: 3)

        let profileVC = UINavigationController(rootViewController: UIViewController())
        profileVC.topViewController?.view.backgroundColor = .white
        profileVC.tabBarItem = UITabBarItem(title: "Profile", image: UIImage(systemName: "person"), tag: 4)

        viewControllers = [homeVC, searchVC, addVC, notificationsVC, profileVC]
    }
}
