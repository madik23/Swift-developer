//
//  AuthorizationViewModel.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 08.09.2025.
//

import Foundation

class AuthorizationViewModel {
    private let baseURL = URL(string: "https://api.court360.ai/rpc/client")!
    
    func loginWithFirebase(idToken: String, completion: @escaping (Result<LoginResponse, Error>) -> Void) {
        
        var request = URLRequest(url: baseURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.timeoutInterval = 15
        
        let body: [String: Any] = [
            "jsonrpc": "2.0",
            "method": "auth.firebaseLogin",
            "params": ["fbIdToken": idToken],
            "id": 1
        ]
        
        do {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        } catch {
            completion(.failure(error))
            return
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("❌ Network error: \(error.localizedDescription)")
                completion(.failure(error))
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse else {
                print("❌ No HTTP response")
                completion(.failure(NSError(domain: "NoHTTPResponse", code: -1)))
                return
            }
            
            print("📡 Status code: \(httpResponse.statusCode)")
            
            guard let data = data else {
                print("❌ Empty response body")
                completion(.failure(NSError(domain: "NoData", code: -1)))
                return
            }
            
            let rawString = String(data: data, encoding: .utf8) ?? "nil"
            print("📦 Raw response: \(rawString)")
            
            do {
                let decoded = try JSONDecoder().decode(RpcResponse<LoginResponse>.self, from: data)
                completion(.success(decoded.result))
            } catch {
                print("❌ JSON decode error: \(error.localizedDescription)")
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
}
