//
//  AuthorizationModel.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 08.09.2025.
//

import Foundation

struct User: Decodable {
    let id: Int
    let name: String
}

struct LoginResponse: Decodable {
    let accessToken: String
    let me: User
    
    private enum CodingKeys: String, CodingKey {
        case accessToken
        case me
    }
}

struct RpcResponse<T: Decodable>: Decodable {
    let result: T
    let id: Int
}
