//
//  AuthorizationView.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 08.09.2025.
//

import UIKit
import AuthenticationServices

class AuthorizationView: UIView {
    private let backgroundView = UIImageView(image: UIImage(named: "authorizationBackgroundView"))
    private let skipButton: UIButton = {
        let button = UIButton()
        button.titleLabel?.font = .systemFont(ofSize: 17, weight: .regular)
        button.setTitleColor(UIColor(hex: "#010C2D"), for: .normal)
        button.setTitle("Skip", for: .normal)
        return button
    }()
    
    private let welcomeTitleView = UIImageView(image: UIImage(named: "welcomeView"))
    private let descriptionLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 0
        label.textAlignment = .left
        label.font = .systemFont(ofSize: 14, weight: .regular)
        label.textColor = UIColor(hex: "#757E9A")
        label.text = "Enter your phone number. We will send you an SMS with a confirmation code to this number."
        return label
    }()
    
    let appleAuthButton: ASAuthorizationAppleIDButton = {
        let button = ASAuthorizationAppleIDButton()
        button.cornerRadius = 8
        return button
    }()
        
    let googleAuthButton: UIButton = {
        let button = UIButton()
        button.setTitle("Continue with Google", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.backgroundColor = .white
        button.titleLabel?.font = .systemFont(ofSize: 16, weight: .medium)
        button.layer.cornerRadius = 8
        button.setImage(UIImage(named: "google"), for: .normal)
        button.imageView?.contentMode = .scaleAspectFit
        return button
    }()
    
    private let termsTextView: UITextView = {
        let textView = UITextView()
        textView.isEditable = false
        textView.isScrollEnabled = false
        textView.backgroundColor = .clear
        textView.textAlignment = .center
        
        let fullText = "By continuing, you agree to Assetsy’s Terms of Use and Privacy Policy"
        let attributed = NSMutableAttributedString(string: fullText, attributes: [
            .font: UIFont.systemFont(ofSize: 13),
            .foregroundColor: UIColor.darkGray
        ])
        
        if let termsRange = fullText.range(of: "Terms of Use") {
            let nsRange = NSRange(termsRange, in: fullText)
            attributed.addAttribute(.link, value: "https://assetsy.com/terms", range: nsRange)
        }
        
        if let privacyRange = fullText.range(of: "Privacy Policy") {
            let nsRange = NSRange(privacyRange, in: fullText)
            attributed.addAttribute(.link, value: "https://assetsy.com/privacy", range: nsRange)
        }
        
        textView.attributedText = attributed
        textView.linkTextAttributes = [
            .foregroundColor: UIColor.systemBlue,
            .underlineStyle: NSUnderlineStyle.single.rawValue
        ]
        
        return textView
    }()
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        setupInitialLayout()
        configureView()
    }
    
    @available(*, unavailable)
    required init?(coder _: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configureView() {
        
    }
    
    func setupInitialLayout() {
        addSubview(backgroundView)
        backgroundView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            backgroundView.topAnchor.constraint(equalTo: topAnchor),
            backgroundView.leadingAnchor.constraint(equalTo: leadingAnchor),
            backgroundView.trailingAnchor.constraint(equalTo: trailingAnchor),
            backgroundView.bottomAnchor.constraint(equalTo: bottomAnchor)
        ])
        
        addSubview(skipButton)
        skipButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            skipButton.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor),
            skipButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16)
        ])
        
        addSubview(welcomeTitleView)
        welcomeTitleView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            welcomeTitleView.topAnchor.constraint(equalTo: skipButton.bottomAnchor, constant: 16),
            welcomeTitleView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16)
        ])
        
        addSubview(descriptionLabel)
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            descriptionLabel.topAnchor.constraint(equalTo: welcomeTitleView.bottomAnchor, constant: 16),
            descriptionLabel.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            descriptionLabel.trailingAnchor.constraint(equalTo: trailingAnchor, constant: 16)
        ])
        
        addSubview(termsTextView)
        termsTextView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            termsTextView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            termsTextView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            termsTextView.bottomAnchor.constraint(equalTo: safeAreaLayoutGuide.bottomAnchor, constant: -32)
        ])
        
        addSubview(googleAuthButton)
        googleAuthButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            googleAuthButton.bottomAnchor.constraint(equalTo: termsTextView.topAnchor, constant: -16),
            googleAuthButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            googleAuthButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            googleAuthButton.heightAnchor.constraint(equalToConstant: 44)
        ])
        
        addSubview(appleAuthButton)
        appleAuthButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            appleAuthButton.bottomAnchor.constraint(equalTo: googleAuthButton.topAnchor, constant: -8),
            appleAuthButton.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            appleAuthButton.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            appleAuthButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }
}

extension AuthorizationView: UITextViewDelegate {
    func textView(_ textView: UITextView,
                  shouldInteractWith URL: URL,
                  in characterRange: NSRange) -> Bool {
        UIApplication.shared.open(URL)
        return false
    }
}
