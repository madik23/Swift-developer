//
//  AuthorizationViewController.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 08.09.2025.
//

import UIKit
import FirebaseAuth
import FirebaseCore

class AuthorizationViewController: UIViewController {
    
    private let viewModel = AuthorizationViewModel()

    private var authView = AuthorizationView()
    
    override func loadView() {
        view = authView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        bindView()
    }
    
    func bindView() {
        authView.googleAuthButton.addTarget(self, action: #selector(googleTapped), for: .touchUpInside)
        authView.appleAuthButton.addTarget(self, action: #selector(appleTapped), for: .touchUpInside)
    }
    
    @objc private func googleTapped() {
        authorizeViaGoogle()
    }
        
    @objc private func appleTapped() {
        handleAuthorizationAppleIDButtonPress()
    }
    
    func sendIdTokenToBackend(token: String) {
        viewModel.loginWithFirebase(idToken: token) { [weak self] result in
            switch result {
            case .success(let loginResponse):
                print("✅ Авторизация на backend успешна")
                print("AccessToken: \(loginResponse.accessToken)")
                print("User: \(loginResponse.me.name)")
                
                DispatchQueue.main.async {
                    UIApplication.shared.setRootViewController(TabBarController())
                }
                
            case .failure(let error):
                print("❌ Ошибка backend авторизации: \(error.localizedDescription)")
                self?.showAlert(title: "Ошибка", message: error.localizedDescription)
            }
        }
    }
}

import AuthenticationServices

extension AuthorizationViewController: ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding {
    func handleAuthorizationAppleIDButtonPress() {
        let appleIDProvider = ASAuthorizationAppleIDProvider()
        let request = appleIDProvider.createRequest()
        request.requestedScopes = [.fullName, .email]
        
        let authorizationController = ASAuthorizationController(authorizationRequests: [request])
        authorizationController.delegate = self
        authorizationController.presentationContextProvider = self
        authorizationController.performRequests()
    }
    
    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        if let credential = authorization.credential as? ASAuthorizationAppleIDCredential,
           let tokenData = credential.identityToken,
           let tokenString = String(data: tokenData, encoding: .utf8) {
            
            let firebaseCredential = OAuthProvider.credential(providerID: .apple, idToken: tokenString)
            
            Auth.auth().signIn(with: firebaseCredential) { [weak self] _, error in
                if let error = error {
                    print("❌ Ошибка Firebase Apple входа: \(error.localizedDescription)")
                    self?.showAlert(title: "Ошибка", message: error.localizedDescription)
                    return
                }
                
                print("✅ Firebase Apple вход успешен")
                self?.sendIdTokenToBackend(token: tokenString)
            }
        }
    }
    
    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        print("❌ Ошибка Apple Sign In: \(error.localizedDescription)")
    }
    
    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        return view.window!
    }
}


import GoogleSignIn

extension AuthorizationViewController {
    func authorizeViaGoogle() {
        GIDSignIn.sharedInstance.signIn(withPresenting: self) { signInResult, error in
            guard error == nil else { return }
            guard let signInResult = signInResult else { return }
            
            signInResult.user.refreshTokensIfNeeded { user, error in
                guard error == nil else { return }
                guard let user = user else { return }
                
                let idToken = user.idToken
                self.sendIdTokenToBackend(token: idToken?.tokenString ?? "")
            }
        }
    }
}
