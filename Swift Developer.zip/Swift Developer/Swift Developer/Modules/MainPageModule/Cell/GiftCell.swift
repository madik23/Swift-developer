//
//  GiftCell.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 08.09.2025.
//
import UIKit

class GiftCell: UICollectionViewCell {
    
    private let giftImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 8
        imageView.backgroundColor = .gray
        imageView.translatesAutoresizingMaskIntoConstraints = false
        return imageView
    }()
    
    private let favoriteIcon: UIImageView = {
        let imageView = UIImageView(image: UIImage(systemName: "heart"))
        imageView.tintColor = .red
        imageView.translatesAutoresizingMaskIntoConstraints = false
        imageView.isHidden = true
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(giftImageView)
        contentView.addSubview(favoriteIcon)
        
        NSLayoutConstraint.activate([
            giftImageView.topAnchor.constraint(equalTo: contentView.topAnchor),
            giftImageView.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            giftImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            giftImageView.bottomAnchor.constraint(equalTo: contentView.bottomAnchor),
            giftImageView.widthAnchor.constraint(equalToConstant: 156),
            giftImageView.heightAnchor.constraint(equalToConstant: 156),
            
            favoriteIcon.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            favoriteIcon.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -8),
            favoriteIcon.widthAnchor.constraint(equalToConstant: 24),
            favoriteIcon.heightAnchor.constraint(equalToConstant: 24)
        ])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func set(image: UIImage, isFavorite: Bool) {
        giftImageView.image = image
        favoriteIcon.image = isFavorite ? UIImage(systemName: "heart.fill") : UIImage(systemName: "heart")
    }
}
