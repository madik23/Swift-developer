//
//  MainPageModel.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 09.09.2025.
//

import UIKit

struct Banner {
    var image: UIImage
    var buttonTitle: String
}

struct Category {
    var image: UIImage
    var title: String
}

struct Gift {
    var image: UIImage
    var isFavorite: Bool
}
