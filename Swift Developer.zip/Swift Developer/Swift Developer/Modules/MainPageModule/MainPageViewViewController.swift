//
//  MainPageViewViewController.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 08.09.2025.
//

import UIKit

class MainPageViewController: UIViewController {
    
    public var banners: [Banner] = [
        Banner(image: UIImage(named: "banner") ?? UIImage(), buttonTitle: "Click to action"),
        Banner(image: UIImage(named: "banner") ?? UIImage(), buttonTitle: "Click to action")
    ]
    
    public var categories: [Category] = [
        Category(image: UIImage(named: "category1") ?? UIImage(), title: "New arrivals"),
        Category(image: UIImage(named: "category2") ?? UIImage(), title: "Mixed flowers"),
        Category(image: UIImage(named: "category3") ?? UIImage(), title: "Thank you"),
        Category(image: UIImage(named: "category1") ?? UIImage(), title: "New arrivals")
    ]
    
    public var gifts: [Gift] = [
        Gift(image: UIImage(named: "gift1") ?? UIImage(), isFavorite: true),
        Gift(image: UIImage(named: "gift2") ?? UIImage(), isFavorite: false)
    ]
    
    private var mainPageView = MainPageView()
    
    override func loadView() {
        view = mainPageView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setCollectionViews()
        
        mainPageView.bannersCollectionView.reloadData()
        mainPageView.categoriesCollectionView.reloadData()
        mainPageView.giftsCollectionView.reloadData()
    }
    
    func setCollectionViews() {
        mainPageView.bannersCollectionView.register(BannerCell.self, forCellWithReuseIdentifier: "BannerCell")
        mainPageView.bannersCollectionView.delegate = self
        mainPageView.bannersCollectionView.dataSource = self
        
        mainPageView.categoriesCollectionView.register(CategoryCell.self, forCellWithReuseIdentifier: "CategoryCell")
        mainPageView.categoriesCollectionView.delegate = self
        mainPageView.categoriesCollectionView.dataSource = self
        
        mainPageView.giftsCollectionView.register(GiftCell.self, forCellWithReuseIdentifier: "GiftCell")
        mainPageView.giftsCollectionView.delegate = self
        mainPageView.giftsCollectionView.dataSource = self
    }
}

extension MainPageViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == mainPageView.bannersCollectionView {
            return banners.count
        } else if collectionView == mainPageView.categoriesCollectionView {
            return categories.count
        } else if collectionView == mainPageView.giftsCollectionView {
            return gifts.count
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == mainPageView.bannersCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BannerCell", for: indexPath) as! BannerCell
            let banner = banners[indexPath.item]
            cell.set(image: banner.image)
            return cell
            
        } else if collectionView == mainPageView.categoriesCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCell", for: indexPath) as! CategoryCell
            let category = categories[indexPath.item]
            cell.set(image: category.image, title: category.title)
            return cell
            
        } else if collectionView == mainPageView.giftsCollectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "GiftCell", for: indexPath) as! GiftCell
            let gift = gifts[indexPath.item]
            cell.set(image: gift.image, isFavorite: gift.isFavorite)
            return cell
        }
        return UICollectionViewCell()
    }
}
