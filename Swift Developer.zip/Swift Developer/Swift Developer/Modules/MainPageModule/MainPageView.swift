//
//  MainPageView.swift
//  Swift Developer
//
//  Created by Madi Kopessov on 08.09.2025.
//

import UIKit

class MainPageView: UIView {
    private let giftsTitleView = UIImageView(image: UIImage(named: "giftsView"))
    
    private let searchBar = UISearchBar()
    
    let bannersCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = CGSize(width: 350, height: 150)
        layout.minimumLineSpacing = 8
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        return collectionView
    }()
    
    let categoriesCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.itemSize = CGSize(width: 80, height: 80)
        layout.minimumLineSpacing = 16
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.showsHorizontalScrollIndicator = false
        return collectionView
    }()
    
    private let viewAllCategoriesButton: UIButton = {
        let button = UIButton(type: .system)
        button.setTitle("View all categories", for: .normal)
        button.setTitleColor(.black, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        button.layer.cornerRadius = 16.0
        button.layer.borderWidth = 1.0
        button.layer.borderColor = UIColor.lightGray.cgColor
        return button
    }()
    
    private let filterStackView: UIStackView = {
        let stack = UIStackView()
        stack.axis = .horizontal
        stack.alignment = .fill
        stack.distribution = .fillEqually
        stack.spacing = 8
        return stack
    }()
    
    private let filterButtons: [UIButton] = {
        let titles = ["Giftboxes", "For Her", "Popular"]
        return titles.map { title in
            let button = UIButton(type: .system)
            button.setTitle(title, for: .normal)
            button.setTitleColor(.black, for: .normal)
            
            button.setImage(UIImage(named: "arrowDown"), for: .normal)
            button.tintColor = .black
            
            button.backgroundColor = UIColor(hex: "EFF3FF")
            
            button.layer.cornerRadius = 16.0
            button.titleLabel?.font = UIFont.systemFont(ofSize: 14, weight: .medium)
            
            button.semanticContentAttribute = .forceRightToLeft
            button.imageEdgeInsets = UIEdgeInsets(top: 0, left: 8, bottom: 0, right: -8)
            return button
        }
    }()
    
    let giftsCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        layout.itemSize = CGSize(width: 156, height: 156)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.backgroundColor = .clear
        collectionView.showsVerticalScrollIndicator = true
        return collectionView
    }()
        
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func setupViews() {
        backgroundColor = UIColor(hex: "EFF3FF")
        
        addSubview(giftsTitleView)
        giftsTitleView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            giftsTitleView.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor),
            giftsTitleView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
        ])
        
        addSubview(searchBar)
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            searchBar.topAnchor.constraint(equalTo: safeAreaLayoutGuide.topAnchor),
            searchBar.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
        ])
        
        addSubview(bannersCollectionView)
        bannersCollectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            bannersCollectionView.topAnchor.constraint(equalTo: giftsTitleView.bottomAnchor, constant: 16),
            bannersCollectionView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            bannersCollectionView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            bannersCollectionView.heightAnchor.constraint(equalToConstant: 150)
        ])
        
        addSubview(categoriesCollectionView)
        categoriesCollectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            categoriesCollectionView.topAnchor.constraint(equalTo: bannersCollectionView.bottomAnchor, constant: 16),
            categoriesCollectionView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            categoriesCollectionView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
            categoriesCollectionView.heightAnchor.constraint(equalToConstant: 80)
        ])
        
        let giftsView = UIView()
        giftsView.backgroundColor = .white
        giftsView.layer.cornerRadius = 8
        
        giftsView.addSubview(viewAllCategoriesButton)
        viewAllCategoriesButton.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            viewAllCategoriesButton.topAnchor.constraint(equalTo: giftsView.topAnchor, constant: 16),
            viewAllCategoriesButton.centerXAnchor.constraint(equalTo: giftsView.centerXAnchor),
            viewAllCategoriesButton.heightAnchor.constraint(equalToConstant: 32),
            viewAllCategoriesButton.widthAnchor.constraint(equalToConstant: 145),
        ])
        
        filterButtons.forEach { filterStackView.addArrangedSubview($0) }
        giftsView.addSubview(filterStackView)
        filterStackView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            filterStackView.topAnchor.constraint(equalTo: viewAllCategoriesButton.bottomAnchor, constant: 16),
            filterStackView.leadingAnchor.constraint(equalTo: giftsView.leadingAnchor, constant: 16),
            filterStackView.trailingAnchor.constraint(equalTo: giftsView.trailingAnchor, constant: -16),
            filterStackView.heightAnchor.constraint(equalToConstant: 32)
        ])
        
        giftsView.addSubview(giftsCollectionView)
        giftsCollectionView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            giftsCollectionView.topAnchor.constraint(equalTo: filterStackView.bottomAnchor, constant: 16),
            giftsCollectionView.leadingAnchor.constraint(equalTo: giftsView.leadingAnchor, constant: 16),
            giftsCollectionView.trailingAnchor.constraint(equalTo: giftsView.trailingAnchor, constant: -16),
            giftsCollectionView.bottomAnchor.constraint(equalTo: giftsView.bottomAnchor, constant: -16),
            giftsCollectionView.heightAnchor.constraint(equalToConstant: 156)
        ])
        
        addSubview(giftsView)
        giftsView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            giftsView.topAnchor.constraint(equalTo: categoriesCollectionView.bottomAnchor, constant: 16),
            giftsView.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
            giftsView.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
        ])
    }
}
